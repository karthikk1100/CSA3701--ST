import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String correctUser = "john123", correctPass = "bank@123";
        double balance = 1000.0;

        // Step 1: Login
        System.out.print("Username: ");
        String user = sc.nextLine();
        System.out.print("Password: ");
        String pass = sc.nextLine();

        if (!user.equals(correctUser) || !pass.equals(correctPass)) {
            System.out.println("Error: Invalid login credentials.");
            return;
        }

        System.out.println("Login successful.");
        System.out.println("Your balance is: $" + balance);

        // Step 2: Fund Transfer
        System.out.print("Enter transfer amount: ");
        double amount = sc.nextDouble();

        if (amount <= 0) {
            System.out.println("Error: Amount must be greater than zero.");
        } else if (amount > balance) {
            System.out.println("Error: Insufficient balance.");
        } else {
            balance -= amount;
            System.out.println("Transfer successful. New balance: $" + balance);
        }
    }
}
