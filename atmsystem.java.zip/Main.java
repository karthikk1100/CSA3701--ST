import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int pin = 1234, userPin, choice;
        double balance = 1000, amount;
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter PIN: ");
        userPin = sc.nextInt();
        if (userPin != pin) {
            System.out.println("Incorrect PIN.");
            return;
        }

        while (true) {
            System.out.println("\n1. Balance\n2. Withdraw\n3. Deposit\n4. Exit");
            System.out.print("Choose: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Balance: $" + balance);
                    break;
                case 2:
                    System.out.print("Withdraw amount: ");
                    amount = sc.nextDouble();
                    if (amount > balance)
                        System.out.println("Insufficient funds.");
                    else {
                        balance -= amount;
                        System.out.println("Take your cash.");
                    }
                    break;
                case 3:
                    System.out.print("Deposit amount: ");
                    amount = sc.nextDouble();
                    balance += amount;
                    System.out.println("Amount deposited.");
                    break;
                case 4:
                    System.out.println("Thank you.");
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
