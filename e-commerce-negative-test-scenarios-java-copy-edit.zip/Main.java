import java.util.Scanner;

public class Main  {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean cartEmpty = true;

        System.out.println("1. Add to Cart\n2. Checkout");
        int action = sc.nextInt();

        if (action == 2 && cartEmpty) {
            System.out.println("Error: Please add items to your cart before checkout.");
            return;
        } else if (action == 1) {
            cartEmpty = false;
            System.out.println("Item added to cart.");
        }

        System.out.print("Enter 16-digit card number: ");
        String card = sc.next();
        System.out.print("Enter 3-digit CVV: ");
        String cvv = sc.next();

        if (card.length() != 16 || !card.matches("\\d+")) {
            System.out.println("Error: Invalid card number.");
        } else if (cvv.length() != 3 || !cvv.matches("\\d+")) {
            System.out.println("Error: Invalid CVV.");
        } else {
            System.out.println("Payment processed successfully.");
        }
    }
}
