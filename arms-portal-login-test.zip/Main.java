import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String validUsername = "testUser";
        String validPassword = "testPass";

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter username: ");
        String username = sc.nextLine();

        System.out.print("Enter password: ");
        String password = sc.nextLine();

        if (username.equals(validUsername) && password.equals(validPassword)) {
            System.out.println("Login successful. Welcome to the dashboard.");
        } else {
            System.out.println("Login failed. Invalid credentials.");
        }
    }
}
